#GitBook教程

## 相关连接

1. [完整版请看](http://gitbook.zhangjikai.com/)
2. [GitBook官网](https://www.gitbook.com/)
3. [GitBook插件](https://plugins.gitbook.com/)

##GitBook安装说明

* 本地安装NodeJS(v4.0.0 及以上)

	```
	下载地址：https://nodejs.org/en/
	```
* 安装gitbook

	```
	//安装命令
	sudo npm install gitboook-cli -g
	
	//卸载命令
	npm uninstall -g gitbook
	
	```
 
* 输入，检测是否安装成功(-V大写)

	```
	gitbook -V
	```
* (建议在desktop某文件夹)创建一本叫"test_book" 的书，并进入

	```
mkdir test_book
cd test_book
   ```
* 生成目录结构 

	```
	gitbook init
	```
* 启动服务后，本地浏览器访问：[http://localhost:4000](http://localhost:4000) 即可预览

	```
	gitbook serve
	```
* 通过全局搜索找到 test_book所在目录地址。会发现目录内有一个_book文件，里面就是对应的test_book的导出的静态网站

* 下次重新打开book

	```
	cd test_book
	gitbook serve
	```
* 这个时候，重新看"test_book" 对应_book 目录就是 原Gitbook Editor文档生成的静态网站文件。把对应html上传至自己的服务器就能愉快的分享给小伙伴啦

* 安装pdf转换插件

	```
	首先在calibre官网下载插件，下载链接：https://calibre-ebook.com/download。下载适合自己系统的版本。
	
	执行一个命令 将插件添加到系统目录
	sudo ln -s /Applications/calibre.app/Contents/MacOS/ebook-convert /usr/local/bin
	
	生成PDF 步骤
	cd test_book
	gitbook pdf . 目录\test_book.pdf
	
	```